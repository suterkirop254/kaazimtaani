// Initialize charts and data
document.addEventListener('DOMContentLoaded', () => {
  initializeEarningsChart();
  loadTransactions();
  setupTaskSystem();
  setupEventListeners();
  setupTaskModal();
});

function initializeEarningsChart() {
  const ctx = document.getElementById('earningsChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'Earnings (KSH)',
        data: [50, 75, 100, 150, 200, 250, 500],
        fill: true,
        backgroundColor: 'rgba(190, 0, 39, 0.1)', // Kenyan red with opacity
        borderColor: '#be0027', // Kenyan red
        tension: 0.4,
        pointBackgroundColor: '#008751', // Kenyan green
        pointBorderColor: '#ffffff',
        pointRadius: 6,
        pointHoverRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            padding: 20,
            font: {
              size: 12,
              family: "'SF Pro Display', sans-serif"
            }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: 'rgba(0, 0, 0, 0.05)'
          },
          ticks: {
            font: {
              family: "'SF Pro Display', sans-serif"
            }
          }
        },
        x: {
          grid: {
            display: false
          },
          ticks: {
            font: {
              family: "'SF Pro Display', sans-serif"
            }
          }
        }
      },
      interaction: {
        intersect: false,
        mode: 'index'
      },
      animation: {
        duration: 1000,
        easing: 'easeInOutQuart'
      }
    }
  });
}

function loadTransactions() {
  const transactions = [
    { date: '2024-01-20', description: 'Task Completion: Like Video', amount: 1 },
    { date: '2024-01-19', description: 'Task Completion: Subscribe', amount: 5 },
    { date: '2024-01-18', description: 'Withdrawal', amount: -100 },
  ];

  const transactionsList = document.getElementById('transactionsList');
  
  transactions.forEach(transaction => {
    const item = document.createElement('div');
    item.className = 'transaction-item';
    item.innerHTML = `
      <div>
        <div>${transaction.description}</div>
        <small>${new Date(transaction.date).toLocaleDateString()}</small>
      </div>
      <div style="color: ${transaction.amount > 0 ? '#059669' : '#dc2626'}">
        ${transaction.amount > 0 ? '+' : ''}KSH ${transaction.amount}
      </div>
    `;
    transactionsList.appendChild(item);
  });
}

function setupEventListeners() {
  // Handle sign out
  document.getElementById('signout').addEventListener('click', () => {
    if (confirm('Are you sure you want to sign out?')) {
      window.location.href = 'https://kazi-mtaani.com/login';
    }
  });
}

const TASKS_PER_PAGE = 10;
let currentPage = 1;
let filteredTasks = [];

const tasks = [
  // YouTube Tasks (10 tasks)
  { platform: 'youtube', task: 'Like video: "Kenya Wildlife Safari"', amount: 1 },
  { platform: 'youtube', task: 'Subscribe to channel: "Kenya Travel Guide"', amount: 5 },
  { platform: 'youtube', task: 'Comment on video: "Maasai Culture"', amount: 2 },
  { platform: 'youtube', task: 'Watch full video (5 min): "Nairobi City Tour"', amount: 3 },
  { platform: 'youtube', task: 'Share video: "Best of Kenya"', amount: 3 },
  
  // TikTok Tasks (5 tasks)
  { platform: 'tiktok', task: 'Follow @KenyanChef', amount: 2 },
  { platform: 'tiktok', task: 'Like video: "Traditional Dance"', amount: 1 },
  { platform: 'tiktok', task: 'Comment on: "Swahili Cuisine"', amount: 2 },
  { platform: 'tiktok', task: 'Share video: "Safari Adventure"', amount: 3 },
  { platform: 'tiktok', task: 'Follow @KenyaWildlife', amount: 2 },
  
  // Facebook Tasks (5 tasks)
  { platform: 'facebook', task: 'Like page: "Kenya Tourism"', amount: 2 },
  { platform: 'facebook', task: 'Share post: "Beautiful Kenya"', amount: 3 },
  { platform: 'facebook', task: 'Join group: "Kenyan Culture"', amount: 4 },
  { platform: 'facebook', task: 'Comment on post: "Local Markets"', amount: 2 },
  { platform: 'facebook', task: 'Like page: "Kenya Wildlife"', amount: 2 },
  
  // Instagram Tasks (5 tasks)
  { platform: 'instagram', task: 'Follow @VisitKenya', amount: 2 },
  { platform: 'instagram', task: 'Like photo: "Sunset Safari"', amount: 1 },
  { platform: 'instagram', task: 'Comment on post: "Beach Life"', amount: 2 },
  { platform: 'instagram', task: 'Save post: "Wildlife Photography"', amount: 1 },
  { platform: 'instagram', task: 'Follow @KenyanFashion', amount: 2 },
  
  // Twitter Tasks (5 tasks)
  { platform: 'twitter', task: 'Follow @KenyaTravel', amount: 2 },
  { platform: 'twitter', task: 'Retweet: "Kenya Facts"', amount: 2 },
  { platform: 'twitter', task: 'Like tweet: "Safari Tips"', amount: 1 },
  { platform: 'twitter', task: 'Reply to tweet: "Visit Kenya"', amount: 2 },
  { platform: 'twitter', task: 'Follow @KenyaSafari', amount: 2 },

  // Spotify Tasks (5 tasks)
  { platform: 'spotify', task: 'Follow playlist: "Kenyan Beats"', amount: 2 },
  { platform: 'spotify', task: 'Listen to song: "African Rhythms" (3 min)', amount: 2 },
  { platform: 'spotify', task: 'Add song to playlist: "Summer Vibes"', amount: 1 },
  { platform: 'spotify', task: 'Share playlist: "Traditional Music"', amount: 2 },
  { platform: 'spotify', task: 'Follow artist: "Kenyan Stars"', amount: 2 }
];

function setupTaskSystem() {
  filteredTasks = [...tasks];
  const platformFilter = document.getElementById('platformFilter');
  const searchInput = document.getElementById('searchTasks');
  const prevButton = document.getElementById('prevPage');
  const nextButton = document.getElementById('nextPage');

  platformFilter?.addEventListener('change', filterTasks);
  searchInput?.addEventListener('input', filterTasks);
  prevButton?.addEventListener('click', () => changePage(-1));
  nextButton?.addEventListener('click', () => changePage(1));

  // Setup modal close handlers
  window.closeTaskModal = function() {
    document.getElementById('taskSubmissionModal').style.display = 'none';
  };

  window.closeSuccessModal = function() {
    document.getElementById('successModal').style.display = 'none';
  };

  // Close modals when clicking outside
  window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
      event.target.style.display = 'none';
    }
  };

  // Handle task submission form
  document.getElementById('taskSubmissionForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    document.getElementById('taskSubmissionModal').style.display = 'none';
    document.getElementById('successModal').style.display = 'block';
    this.reset();
    document.getElementById('imagePreview').innerHTML = '';
  });

  // Handle screenshot upload preview
  document.getElementById('screenshotProof')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('imagePreview');
    
    if (file) {
      const reader = new FileReader();
      reader.onload = function(e) {
        preview.innerHTML = `<img src="${e.target.result}" alt="Screenshot preview">`;
      }
      reader.readAsDataURL(file);
    }
  });

  renderTasks();
}

function filterTasks() {
  const platform = document.getElementById('platformFilter').value;
  const searchTerm = document.getElementById('searchTasks').value.toLowerCase();

  filteredTasks = tasks.filter(task => {
    const platformMatch = platform === 'all' || task.platform === platform;
    const searchMatch = task.task.toLowerCase().includes(searchTerm);
    return platformMatch && searchMatch;
  });

  currentPage = 1;
  renderTasks();
}

function changePage(delta) {
  const maxPages = Math.ceil(filteredTasks.length / TASKS_PER_PAGE);
  currentPage = Math.max(1, Math.min(currentPage + delta, maxPages));
  renderTasks();
}

function renderTasks() {
  const tableBody = document.getElementById('taskTableBody');
  if (!tableBody) return;

  const pageItems = filteredTasks.slice((currentPage - 1) * TASKS_PER_PAGE, currentPage * TASKS_PER_PAGE);

  tableBody.innerHTML = pageItems.map(task => `
    <tr class="task-row">
      <td>
        <svg class="platform-icon" viewBox="0 0 24 24">
          <!-- Platform-specific icon paths -->
        </svg>
        ${task.platform.charAt(0).toUpperCase() + task.platform.slice(1)}
      </td>
      <td>
        ${task.task}
        ${task.url ? `<br><a href="${task.url}" target="_blank" rel="noopener noreferrer" class="task-url">View Content</a>` : ''}
      </td>
      <td>${task.amount}</td>
      <td><button class="task-btn" onclick="showTaskModal(${JSON.stringify(task).replace(/"/g, '&quot;')})">Apply Task</button></td>
    </tr>
  `).join('');
}

window.showTaskModal = function(task) {
  const modal = document.getElementById('taskSubmissionModal');
  const taskInfo = modal.querySelector('.task-info');
  
  taskInfo.innerHTML = `
    <p><strong>Platform:</strong> ${task.platform}</p>
    <p><strong>Task:</strong> ${task.task}</p>
    <p><strong>Amount:</strong> KSH ${task.amount}</p>
    <p><strong>Instructions:</strong></p>
    <ol>
      <li>Complete the task as specified</li>
      <li>Take a screenshot showing proof of completion</li>
      <li>Upload the screenshot and provide any additional notes</li>
      <li>Submit for review</li>
    </ol>
  `;
  
  modal.style.display = 'block';
};

function setupTaskModal() {
  const modal = document.getElementById('addTaskModal');
  const btn = document.getElementById('addTaskBtn');
  const spans = document.getElementsByClassName('close');
  const form = document.getElementById('addTaskForm');

  // Handle all close buttons
  Array.from(spans).forEach(span => {
    span.onclick = () => {
      document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
      });
    };
  });

  btn.onclick = () => {
    modal.style.display = 'block';
  }

  // Close any modal when clicking outside
  window.onclick = (event) => {
    if (event.target.classList.contains('modal')) {
      document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
      });
    }
  }

  // Form submission handling
  form.onsubmit = (e) => {
    e.preventDefault();
    
    const newTask = {
      platform: document.getElementById('taskPlatform').value,
      task: document.getElementById('taskDescription').value,
      url: document.getElementById('taskUrl').value,
      amount: parseInt(document.getElementById('taskAmount').value)
    };

    try {
      new URL(newTask.url);
    } catch (e) {
      alert('Please enter a valid URL starting with http:// or https://');
      return;
    }

    // Add new task to both arrays
    tasks.unshift(newTask);
    filteredTasks.unshift(newTask);
    
    form.reset();
    modal.style.display = 'none';
    
    // Render the updated task list
    renderTasks();
    
    const successMsg = document.createElement('div');
    successMsg.className = 'success-message';
    successMsg.textContent = 'Task added successfully!';
    document.querySelector('.task-section').prepend(successMsg);
    
    setTimeout(() => {
      successMsg.remove();
    }, 3000);
  }
}

// Advertisement Modal Functions
window.showAdModal = function() {
  document.getElementById('adModal').style.display = 'block';
};

window.closeAdModal = function() {
  document.getElementById('adModal').style.display = 'none';
};

// Initialize advertisement form handling
document.getElementById('adForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Thank you! Your advertisement request has been submitted for review.');
  closeAdModal();
});

// Close modal when clicking outside
window.onclick = function(event) {
  if (event.target.classList.contains('modal')) {
    event.target.style.display = 'none';
  }
};